package domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String ime;
	private String prezime;
	private String brojIndexa;
	private String datumRodjenja;
	@OneToOne
	@JoinColumn(name = "STUD_PROG_ID")
	private StudentProgram studentProgram;
	
	public Student(Long id, String ime, String prezime, String brojIndexa, String datumRodjenja,
			StudentProgram studentProgram) {
		super();
		this.id = id;
		this.ime = ime;
		this.prezime = prezime;
		this.brojIndexa = brojIndexa;
		this.datumRodjenja = datumRodjenja;
		this.studentProgram = studentProgram;
	}

	public Student(String ime, String prezime, String brojIndexa, String datumRodjenja, StudentProgram studentProgram) {
		super();

		this.ime = ime;
		this.prezime = prezime;
		this.brojIndexa = brojIndexa;
		this.datumRodjenja = datumRodjenja;
		this.studentProgram = studentProgram;
	}

	public Student() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public String getBrojIndexa() {
		return brojIndexa;
	}

	public void setBrojIndexa(String brojIndexa) {
		this.brojIndexa = brojIndexa;
	}

	public String getDatumRodjenja() {
		return datumRodjenja;
	}

	public void setDatumRodjenja(String datumRodjenja) {
		this.datumRodjenja = datumRodjenja;
	}

	public StudentProgram getStudentProgram() {
		return studentProgram;
	}

	public void setStudentProgram(StudentProgram studentProgram) {
		this.studentProgram = studentProgram;
	}

}
