package domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.UniqueConstraint;

@Entity
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String ime;
	@OneToMany
	private List<Profesor> profesori;

	public Department(Long id, String name) {
		super();
		this.id = id;
		this.ime = ime;
		this.profesori = new ArrayList<Profesor>();
	}

	public Department(String name) {
		super();

		this.ime = ime;
		this.profesori = new ArrayList<Profesor>();
	}

	public Department() {
		this.profesori = new ArrayList<Profesor>();

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + ime + "]";
	}

}
