package domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Profesor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String ime;
	private String zvanje;
	private String prezime;
	private Date daumRadOdnosa;

	@OneToMany(mappedBy = "profesor", orphanRemoval = true, cascade = CascadeType.ALL)
	private Set<ProfPredEntity> ProfPredEntity;

	public Profesor(String ime, String zvanje, String prezime, Date daumRadOdnosa, List<Predmet> predmeti) {
		super();
		this.ime = ime;
		this.zvanje = zvanje;
		this.prezime = prezime;
		this.daumRadOdnosa = daumRadOdnosa;
	
	}

	public Profesor() {
	

	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getZvanje() {
		return zvanje;
	}

	public void setZvanje(String zvanje) {
		this.zvanje = zvanje;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public Date getDaumRadOdnosa() {
		return daumRadOdnosa;
	}

	public void setDaumRadOdnosa(Date daumRadOdnosa) {
		this.daumRadOdnosa = daumRadOdnosa;
	}

	

	
	

	@Override
	public String toString() {
		return "Profesor [ime=" + ime + ", zvanje=" + zvanje + ", prezime=" + prezime + ", daumRadOdnosa="
				+ daumRadOdnosa + ", predmeti=" + "]";
	}

}
