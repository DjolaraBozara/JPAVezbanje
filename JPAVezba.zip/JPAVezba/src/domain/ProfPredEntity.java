package domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "ProfPredEntity", uniqueConstraints = @UniqueConstraint(columnNames = {"PROFESOR_ID","COURSE_ID"}))
public class ProfPredEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	@JoinColumn(name = "PROFESOR_ID", referencedColumnName = "ID")
	private Profesor profesor;
	@ManyToOne
	@JoinColumn(name = "PREDMET_ID", referencedColumnName = "ID")
	private Predmet predmet;
	

}
