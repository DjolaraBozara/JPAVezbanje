package domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class ProfPredKey implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long profesorId;
	private Long predmetId;

	public ProfPredKey(Long profesorId, Long predmetId) {
		super();
		this.profesorId = profesorId;
		this.predmetId = predmetId;
	}

	public ProfPredKey() {

	}

	public Long getProfesorId() {
		return profesorId;
	}

	public void setProfesorId(Long profesorId) {
		this.profesorId = profesorId;
	}

	public Long getPredmetId() {
		return predmetId;
	}

	public void setPredmetId(Long predmetId) {
		this.predmetId = predmetId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((predmetId == null) ? 0 : predmetId.hashCode());
		result = prime * result + ((profesorId == null) ? 0 : profesorId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfPredKey other = (ProfPredKey) obj;
		if (predmetId == null) {
			if (other.predmetId != null)
				return false;
		} else if (!predmetId.equals(other.predmetId))
			return false;
		if (profesorId == null) {
			if (other.profesorId != null)
				return false;
		} else if (!profesorId.equals(other.profesorId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProfPred [profesorId=" + profesorId + ", predmetId=" + predmetId + "]";
	}

}
