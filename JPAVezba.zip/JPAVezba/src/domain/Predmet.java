package domain;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Predmet {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
private String ime;
private String brojESP;
@OneToOne
@JoinColumn(name = "PRED_STUDPRROG_ID")
private StudentProgram studProgram;
private int semestar;

@OneToMany(mappedBy = "predmet", orphanRemoval = true,cascade = CascadeType.ALL)
private Set<ProfPredEntity> ProfPredEntity;

public Predmet() {
	
}

public Predmet(Long id, String ime, String brojESP, StudentProgram studProgram, int semestar,
		Set<domain.ProfPredEntity> profPredEntity) {
	super();
	this.id = id;
	this.ime = ime;
	this.brojESP = brojESP;
	this.studProgram = studProgram;
	this.semestar = semestar;
	ProfPredEntity = profPredEntity;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getIme() {
	return ime;
}

public void setIme(String ime) {
	this.ime = ime;
}

public String getBrojESP() {
	return brojESP;
}

public void setBrojESP(String brojESP) {
	this.brojESP = brojESP;
}

public StudentProgram getStudProgram() {
	return studProgram;
}

public void setStudProgram(StudentProgram studProgram) {
	this.studProgram = studProgram;
}

public int getSemestar() {
	return semestar;
}

public void setSemestar(int semestar) {
	this.semestar = semestar;
}

public Set<ProfPredEntity> getProfPredEntity() {
	return ProfPredEntity;
}

public void setProfPredEntity(Set<ProfPredEntity> profPredEntity) {
	ProfPredEntity = profPredEntity;
}

@Override
public String toString() {
	return "Predmet [id=" + id + ", ime=" + ime + ", brojESP=" + brojESP + ", studProgram=" + studProgram
			+ ", semestar=" + semestar + ", ProfPredEntity=" + ProfPredEntity + "]";
}



}
