package domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class IspitStudKey implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long profIspitId;
	private Long studentId;

	public IspitStudKey(Long profIspitId, Long studentId) {
		super();
		this.profIspitId = profIspitId;
		this.studentId = studentId;
	}

	private IspitStudKey() {

	}

	public Long getProfIspitId() {
		return profIspitId;
	}

	public void setProfIspitId(Long profIspitId) {
		this.profIspitId = profIspitId;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profIspitId == null) ? 0 : profIspitId.hashCode());
		result = prime * result + ((studentId == null) ? 0 : studentId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IspitStudKey other = (IspitStudKey) obj;
		if (profIspitId == null) {
			if (other.profIspitId != null)
				return false;
		} else if (!profIspitId.equals(other.profIspitId))
			return false;
		if (studentId == null) {
			if (other.studentId != null)
				return false;
		} else if (!studentId.equals(other.studentId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "IspitStudKey [profIspitId=" + profIspitId + ", studentId=" + studentId + "]";
	}

}
